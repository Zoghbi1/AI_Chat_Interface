# main.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Dict
import os
from dotenv import load_dotenv
import json
import datetime

# Load environment variables
load_dotenv()

app = FastAPI(
    title="AI Chat Interface",
    description="A minimal chat interface with AI integration and summary generation.",
)

# --- Configuration ---
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
# You can choose other models like "gpt-4", "gpt-3.5-turbo-0125", etc.
AI_MODEL = "gpt-3.5-turbo"
MAX_USER_MESSAGES_FOR_SUMMARY = 3
CONVERSATION_SAVE_DIR = "conversations"

# Ensure conversation save directory exists
os.makedirs(CONVERSATION_SAVE_DIR, exist_ok=True)

# --- In-memory storage for conversations (for simplicity) ---
# In a real application, this would be a database
conversations: Dict[str, List[Dict[str, str]]] = {}
user_message_counts: Dict[str, int] = {}


# --- Pydantic Models for Request/Response ---
class ChatRequest(BaseModel):
    session_id: str  # Unique ID for each conversation
    user_message: str


class ChatResponse(BaseModel):
    session_id: str
    ai_response: str
    summary: str | None = None
    message_count: int


# --- AI Integration (Helper Function) ---
async def get_ai_response(messages: List[Dict[str, str]]) -> str:
    """Sends messages to the AI model and returns its response."""
    if not OPENAI_API_KEY:
        # As per task: comment out if no API key
        print("Warning: OPENAI_API_KEY not set. Returning dummy AI response.")
        return "This is a dummy AI response because no API key is configured."

    try:
        from openai import AsyncOpenAI

        client = AsyncOpenAI(api_key=OPENAI_API_KEY)
        response = await client.chat.completions.create(
            model=AI_MODEL,
            messages=messages,
            temperature=0.7,  # Adjust creativity
            max_tokens=150,  # Limit response length
        )
        return response.choices[0].message.content
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI API error: {e}")


async def get_ai_summary(conversation_history: List[Dict[str, str]]) -> str:
    """Generates a summary of the conversation using the AI model."""
    if not OPENAI_API_KEY:
        print("Warning: OPENAI_API_KEY not set. Returning dummy summary.")
        return json.dumps(
            {"zusammenfassung": "Dummy summary because no API key is configured."}
        )

    summary_prompt = {
        "role": "user",
        "content": (
            "Fasse das vorherige Gespräch mit dem Nutzer in maximal drei Sätzen zusammen "
            'und gib das Ergebnis im folgenden JSON-Format aus: { "zusammenfassung": "..." }'
        ),
    }
    # Send the entire conversation history + summary prompt to the AI
    messages_for_summary = conversation_history + [summary_prompt]

    try:
        from openai import AsyncOpenAI

        client = AsyncOpenAI(api_key=OPENAI_API_KEY)
        response = await client.chat.completions.create(
            model=AI_MODEL,
            messages=messages_for_summary,
            temperature=0.5,
            max_tokens=100,
            response_format={"type": "json_object"},  # Request JSON output
        )
        summary_content = response.choices[0].message.content
        # Attempt to parse the JSON response
        try:
            parsed_summary = json.loads(summary_content)
            return parsed_summary.get(
                "zusammenfassung", "Summary not found in AI response."
            )
        except json.JSONDecodeError:
            print(
                f"Warning: AI did not return valid JSON for summary: {summary_content}"
            )
            return "Could not parse summary from AI response."
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI summary API error: {e}")


# --- File Saving (Helper Function) ---
def save_conversation(
    session_id: str, history: List[Dict[str, str]], summary: str | None = None
):
    """Saves the conversation history and summary to a JSON file."""
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = os.path.join(
        CONVERSATION_SAVE_DIR, f"conversation_{session_id}_{timestamp}.json"
    )

    data_to_save = {
        "session_id": session_id,
        "timestamp": timestamp,
        "conversation": history,
        "summary": summary,
    }

    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data_to_save, f, indent=2, ensure_ascii=False)
    print(f"Conversation saved to {filename}")


# --- API Endpoint ---
@app.post("/chat", response_model=ChatResponse)
async def chat_with_ai(request: ChatRequest):
    session_id = request.session_id
    user_message = request.user_message

    # Initialize conversation if new session
    if session_id not in conversations:
        conversations[session_id] = []
        user_message_counts[session_id] = 0

    # Add user message to history
    conversations[session_id].append({"role": "user", "content": user_message})
    user_message_counts[session_id] += 1

    # Get AI response for the current message
    ai_response_content = await get_ai_response(conversations[session_id])
    conversations[session_id].append(
        {"role": "assistant", "content": ai_response_content}
    )

    summary_content = None
    # Check if it's time to generate a summary
    if user_message_counts[session_id] == MAX_USER_MESSAGES_FOR_SUMMARY:
        print(
            f"User {session_id} has sent {MAX_USER_MESSAGES_FOR_SUMMARY} messages. Generating summary..."
        )
        summary_content = await get_ai_summary(conversations[session_id])
        conversations[session_id].append(
            {"role": "system", "content": f"Summary: {summary_content}"}
        )

        # Save the conversation after summary generation
        save_conversation(session_id, conversations[session_id], summary_content)

        # Reset count for potential future interactions in the same session, or clear history
        # For this task, we'll assume the conversation cycle ends here for summary purposes.
        # If more messages are expected, you might want to reset user_message_counts[session_id] = 0
        # or manage conversation segments.

    return ChatResponse(
        session_id=session_id,
        ai_response=ai_response_content,
        summary=summary_content,
        message_count=user_message_counts[session_id],
    )


# --- Run the application ---
# To run: uvicorn main:app --reload
# Access at: http://127.0.0.1:8000/docs
